package app.companion

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(val fromUser: Boolean, val text: String)

/** Любой источник ответов ИИ. Сейчас: демо-режим и ваш собственный HTTPS-сервер. */
interface AiProvider {
    suspend fun reply(history: List<ChatMessage>, memories: List<String>): Result<String>
}

/** Демо-режим: простые шаблонные ответы, НЕ настоящий ИИ. Ничего не отправляет в интернет. */
class DemoProvider : AiProvider {
    private val fallback = listOf(
        "Кря! Расскажи подробнее.",
        "Интересно! А что дальше?",
        "Я пока в демо-режиме, но слушаю внимательно.",
        "Хм, надо подумать… кря.",
        "Можешь меня погладить: нажми на меня на главном экране."
    )

    override suspend fun reply(history: List<ChatMessage>, memories: List<String>): Result<String> {
        delay(700)
        val last = history.lastOrNull { it.fromUser }?.text.orEmpty().lowercase()
        val name = memories.firstOrNull { it.startsWith("Имя: ") }?.removePrefix("Имя: ")
        fun has(pattern: String) = Regex(pattern).containsMatchIn(last)
        val text = when {
            has("как тебя зовут|кто ты") -> "Я Companion, твоя утка. Кря!"
            has("как меня зовут|мое имя|моё имя") ->
                if (name != null) "Тебя зовут $name." else "Пока не знаю. Включи память и скажи «меня зовут …»."
            has("привет|здравствуй|добрый (день|вечер|утро)|хай") ->
                if (name != null) "Кря! Привет, $name!" else "Кря! Привет!"
            has("как дела|как ты") -> "Отлично, перья в порядке. А у тебя как?"
            has("груст|плохо|устал|тоск|обидно") -> "Мне жаль. Я посижу рядом, кря."
            has("спокойной ночи|спать|спи") -> "Ладно, подремлю. Зззз…"
            has("спасибо|благодар") -> "Всегда пожалуйста!"
            has("что ты умеешь|умеешь") -> "Чешусь, прыгаю, болтаю и могу озвучивать ответы. ИИ пока в демо-режиме."
            has("запомни|меня зовут") -> "Принято. Если память включена в настройках, я это сохраню."
            else -> fallback.random()
        }
        return Result.success(text)
    }
}

/**
 * Ваш собственный сервер-посредник (ключ ИИ хранится на сервере, не в приложении).
 * POST https://... JSON: {"messages":[{"role":"user|assistant","content":"..."}],"memory":["..."]}
 * Ответ: {"reply":"текст"}
 */
class BackendProvider(private val url: String) : AiProvider {
    override suspend fun reply(history: List<ChatMessage>, memories: List<String>): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val conn = URL(url).openConnection() as HttpURLConnection
                try {
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 10000
                    conn.readTimeout = 30000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    val msgs = JSONArray()
                    for (m in history.takeLast(20)) {
                        msgs.put(
                            JSONObject()
                                .put("role", if (m.fromUser) "user" else "assistant")
                                .put("content", m.text)
                        )
                    }
                    val body = JSONObject().put("messages", msgs).put("memory", JSONArray(memories))
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    if (code !in 200..299) error("HTTP $code")
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    JSONObject(resp).getString("reply")
                } finally {
                    conn.disconnect()
                }
            }
        }
}
