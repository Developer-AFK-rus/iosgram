package app.companion

import android.app.Application
import android.content.Context
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File
import java.util.Locale

enum class EmojiEffect(val label: String) {
    SPIN("Вращение"), BOUNCE("Прыжок"), PULSE("Пульс")
}

class CompanionViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("companion", Context.MODE_PRIVATE)
    val duck = DuckController()

    // ---- настройки Companion / озвучки / памяти / сервера ----
    var animationsEnabled by mutableStateOf(prefs.getBoolean("anim", true))
        private set
    var ttsEnabled by mutableStateOf(prefs.getBoolean("tts", true))
        private set
    var ttsRate by mutableFloatStateOf(prefs.getFloat("rate", 1f))
        private set
    var ttsPitch by mutableFloatStateOf(prefs.getFloat("pitch", 1.2f))
        private set
    var memoryEnabled by mutableStateOf(prefs.getBoolean("mem", false))
        private set
    var backendEnabled by mutableStateOf(prefs.getBoolean("be", false))
        private set
    var backendUrl by mutableStateOf(prefs.getString("beUrl", "") ?: "")
        private set
    val backendActive: Boolean get() = backendEnabled && backendUrl.startsWith("https://")

    // ---- профиль V2 ----
    var displayName by mutableStateOf(prefs.getString("name", "") ?: "")
        private set
    var emoji by mutableStateOf(prefs.getString("emoji", "🦆") ?: "")
        private set
    var emojiAnim by mutableStateOf(prefs.getBoolean("emojiAnim", true))
        private set
    var emojiSpeed by mutableFloatStateOf(prefs.getFloat("emojiSpeed", 1f))
        private set
    var emojiEffect by mutableStateOf(
        runCatching { EmojiEffect.valueOf(prefs.getString("emojiEffect", "SPIN") ?: "SPIN") }
            .getOrDefault(EmojiEffect.SPIN)
    )
        private set
    var gifFile by mutableStateOf<File?>(
        prefs.getString("gif", null)
            ?.let { File(app.filesDir, it) }
            ?.takeIf { it.exists() }
    )
        private set

    // ---- чат (контекст только текущей сессии) ----
    val messages = mutableStateListOf(ChatMessage(false, "Кря! Я Companion. Напиши мне что-нибудь."))
    var thinking by mutableStateOf(false)
        private set

    // ---- память ----
    val memories = mutableStateListOf<String>().also { list ->
        prefs.getString("memories", null)?.let { s ->
            runCatching {
                val a = JSONArray(s)
                for (i in 0 until a.length()) list.add(a.getString(i))
            }
        }
    }

    // ---- озвучка ----
    var ttsAvailable by mutableStateOf(false)
        private set
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
                ttsAvailable = true
            } else {
                ttsAvailable = false
            }
        }
    }

    fun speak(text: String) {
        if (!ttsEnabled || !ttsAvailable) return
        tts?.setSpeechRate(ttsRate)
        tts?.setPitch(ttsPitch)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "companion")
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    override fun onCleared() {
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }

    // ---- чат ----
    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || thinking) return
        stopSpeaking()
        messages.add(ChatMessage(true, t))
        maybeRemember(t)
        thinking = true
        viewModelScope.launch {
            val provider: AiProvider =
                if (backendActive) BackendProvider(backendUrl) else DemoProvider()
            val lookJob = launch { duck.doLook() }
            val result = provider.reply(
                messages.toList(),
                if (memoryEnabled) memories.toList() else emptyList()
            )
            lookJob.cancelAndJoin()
            duck.resetLook()
            thinking = false
            result.onSuccess { r ->
                messages.add(ChatMessage(false, r))
                speak(r)
                val m = moodFor(t)
                if (m == Mood.SLEEPY) duck.sleep() else duck.flash(m)
            }.onFailure {
                messages.add(
                    ChatMessage(false, "Кря… не получилось связаться с сервером ИИ. Проверь адрес в настройках.")
                )
                duck.flash(Mood.SAD)
            }
        }
    }

    private fun moodFor(user: String): Mood {
        val u = user.lowercase()
        return when {
            Regex("груст|плохо|устал|тоск|обидно").containsMatchIn(u) -> Mood.SAD
            Regex("спокойной ночи|спать|спи").containsMatchIn(u) -> Mood.SLEEPY
            Regex("вау|ого|неожиданно|правда\\?").containsMatchIn(u) -> Mood.SURPRISED
            else -> Mood.HAPPY
        }
    }

    // ---- память ----
    private fun maybeRemember(t: String) {
        if (!memoryEnabled) return
        val lower = t.lowercase()
        val item: String? = when {
            lower.startsWith("запомни") ->
                t.drop(7).trim(' ', ':', ',', '.', '-').ifBlank { null }
            lower.startsWith("меня зовут") ->
                t.drop(10).trim(' ', '.', '!').ifBlank { null }?.let { "Имя: $it" }
            else -> null
        }
        if (item == null) return
        if (item.startsWith("Имя: ")) memories.removeAll { it.startsWith("Имя: ") }
        if (item !in memories && memories.size < 50) {
            memories.add(item.take(200))
            saveMemories()
        }
    }

    private fun saveMemories() {
        prefs.edit().putString("memories", JSONArray(memories.toList()).toString()).apply()
    }

    fun removeMemory(index: Int) {
        if (index in memories.indices) {
            memories.removeAt(index)
            saveMemories()
        }
    }

    fun clearMemories() {
        memories.clear()
        saveMemories()
    }

    // ---- сеттеры настроек ----
    fun updateAnimations(v: Boolean) { animationsEnabled = v; prefs.edit().putBoolean("anim", v).apply() }
    fun updateTts(v: Boolean) {
        ttsEnabled = v
        if (!v) stopSpeaking()
        prefs.edit().putBoolean("tts", v).apply()
    }
    fun updateRate(v: Float) { ttsRate = v; prefs.edit().putFloat("rate", v).apply() }
    fun updatePitch(v: Float) { ttsPitch = v; prefs.edit().putFloat("pitch", v).apply() }
    fun updateMemory(v: Boolean) { memoryEnabled = v; prefs.edit().putBoolean("mem", v).apply() }
    fun updateBackendEnabled(v: Boolean) { backendEnabled = v; prefs.edit().putBoolean("be", v).apply() }
    fun updateBackendUrl(v: String) { backendUrl = v.trim(); prefs.edit().putString("beUrl", backendUrl).apply() }

    fun updateName(v: String) { displayName = v.take(32); prefs.edit().putString("name", displayName).apply() }
    fun updateEmoji(v: String) { emoji = v; prefs.edit().putString("emoji", v).apply() }
    fun updateEmojiAnim(v: Boolean) { emojiAnim = v; prefs.edit().putBoolean("emojiAnim", v).apply() }
    fun updateEmojiSpeed(v: Float) { emojiSpeed = v; prefs.edit().putFloat("emojiSpeed", v).apply() }
    fun updateEmojiEffect(v: EmojiEffect) { emojiEffect = v; prefs.edit().putString("emojiEffect", v.name).apply() }

    // ---- GIF-аватар (хранится только локально в приложении) ----
    fun saveGif(uri: Uri): Boolean {
        val ctx = getApplication<Application>()
        val newName = "avatar_${System.currentTimeMillis()}.gif"
        val out = File(ctx.filesDir, newName)
        val ok = runCatching {
            val input = ctx.contentResolver.openInputStream(uri) ?: error("no stream")
            input.use { inp ->
                out.outputStream().use { o ->
                    val buf = ByteArray(8192)
                    var total = 0L
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > 8L * 1024 * 1024) error("too big")
                        o.write(buf, 0, n)
                    }
                }
            }
            val head = ByteArray(3)
            out.inputStream().use { it.read(head) }
            if (String(head, Charsets.US_ASCII) != "GIF") error("not gif")
        }.onFailure { out.delete() }.isSuccess
        if (ok) {
            gifFile?.delete()
            gifFile = out
            prefs.edit().putString("gif", newName).apply()
        }
        return ok
    }

    fun removeGif() {
        gifFile?.delete()
        gifFile = null
        prefs.edit().remove("gif").apply()
    }
}
