package app.companion

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class Mood(val label: String) {
    NEUTRAL("спокойна"),
    HAPPY("радуется"),
    SURPRISED("удивлена"),
    SLEEPY("сонная"),
    SAD("грустит")
}

/** Состояние и анимации утки Companion. Все значения читаются только при отрисовке. */
class DuckController {
    val jump = Animatable(0f)
    val wiggle = Animatable(0f)
    val scratch = Animatable(0f)
    val lookX = Animatable(0f)
    val blink = Animatable(0f)

    var sleeping by mutableStateOf(false)
    var mood by mutableStateOf(Mood.NEUTRAL)

    suspend fun doJump() {
        jump.animateTo(1f, tween(200, easing = FastOutSlowInEasing))
        jump.animateTo(
            0f,
            spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)
        )
    }

    suspend fun doWiggle() {
        repeat(4) {
            wiggle.animateTo(1f, tween(90))
            wiggle.animateTo(-1f, tween(90))
        }
        wiggle.animateTo(0f, tween(90))
    }

    suspend fun doScratch() {
        scratch.animateTo(1f, tween(250))
        repeat(5) {
            scratch.animateTo(0.75f, tween(110))
            scratch.animateTo(1f, tween(110))
        }
        scratch.animateTo(0f, tween(250))
    }

    suspend fun doLook() {
        lookX.animateTo(-1f, tween(300))
        delay(500)
        lookX.animateTo(1f, tween(500))
        delay(500)
        lookX.animateTo(0f, tween(300))
    }

    suspend fun resetLook() {
        lookX.animateTo(0f, tween(200))
    }

    suspend fun doBlink() {
        blink.animateTo(1f, tween(70))
        blink.animateTo(0f, tween(90))
    }

    suspend fun flash(m: Mood, ms: Long = 2500) {
        mood = m
        delay(ms)
        if (mood == m) mood = Mood.NEUTRAL
    }

    fun sleep() {
        sleeping = true
        mood = Mood.SLEEPY
    }

    suspend fun wake() {
        sleeping = false
        mood = Mood.SURPRISED
        doJump()
        delay(600)
        if (mood == Mood.SURPRISED) mood = Mood.NEUTRAL
    }

    suspend fun touch() {
        if (sleeping) {
            wake()
        } else {
            mood = Mood.HAPPY
            doJump()
            delay(700)
            if (mood == Mood.HAPPY) mood = Mood.NEUTRAL
        }
    }

    /** Случайное «живое» поведение. Работает только пока экран с уткой на экране. */
    suspend fun idleLoop() {
        coroutineScope {
            launch {
                while (true) {
                    delay(Random.nextLong(2500, 5500))
                    if (!sleeping) doBlink()
                }
            }
            while (true) {
                delay(Random.nextLong(2000, 5000))
                if (sleeping) {
                    if (Random.nextInt(5) == 0) wake()
                    continue
                }
                when (Random.nextInt(8)) {
                    0 -> doScratch()
                    1 -> doWiggle()
                    2 -> doJump()
                    3, 4 -> doLook()
                    5 -> if (mood == Mood.NEUTRAL && Random.nextInt(3) == 0) sleep()
                    else -> {}
                }
            }
        }
    }
}

@Composable
fun DuckCompanion(c: DuckController, animationsEnabled: Boolean, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    LaunchedEffect(animationsEnabled) {
        if (animationsEnabled) c.idleLoop()
    }
    Box(
        modifier
            .aspectRatio(1f)
            .pointerInput(Unit) {
                detectTapGestures { scope.launch { c.touch() } }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) { drawDuck(c) }
        if (c.sleeping) Zzz()
    }
}

@Composable
private fun BoxScope.Zzz() {
    val t = rememberInfiniteTransition(label = "zzz")
    val a by t.animateFloat(
        0.3f, 1f,
        infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "zzzAlpha"
    )
    Text(
        "Z z z",
        color = MaterialTheme.colorScheme.primary.copy(alpha = a),
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        modifier = Modifier.align(Alignment.TopEnd).padding(top = 16.dp, end = 24.dp)
    )
}

private val Yellow = Color(0xFFFFD54F)
private val YellowDark = Color(0xFFFFB300)
private val YellowLight = Color(0xFFFFE082)
private val Orange = Color(0xFFFF9800)
private val Ink = Color(0xFF3E2723)

private fun DrawScope.closedEye(x: Float, y: Float, r: Float) {
    drawArc(
        Ink, 0f, 180f, false,
        topLeft = Offset(x - r, y - r * 0.6f),
        size = Size(r * 2f, r * 1.2f),
        style = Stroke(width = r * 0.5f, cap = StrokeCap.Round)
    )
}

private fun DrawScope.happyEye(x: Float, y: Float, r: Float) {
    drawArc(
        Ink, 180f, 180f, false,
        topLeft = Offset(x - r, y - r * 0.6f),
        size = Size(r * 2f, r * 1.2f),
        style = Stroke(width = r * 0.5f, cap = StrokeCap.Round)
    )
}

private fun DrawScope.normalEye(x: Float, y: Float, r: Float, open: Float) {
    val o = open.coerceIn(0.1f, 1f)
    drawOval(Ink, Offset(x - r, y - r * o), Size(r * 2f, r * 2f * o))
    drawCircle(Color.White, r * 0.35f, Offset(x - r * 0.25f, y - r * 0.3f * o))
}

private fun DrawScope.drawDuck(c: DuckController) {
    val s = size.minDimension
    val j = c.jump.value
    val w = c.wiggle.value
    val sc = c.scratch.value
    val look = c.lookX.value
    val sleeping = c.sleeping
    val eyeOpen = if (sleeping) 0f else 1f - c.blink.value
    val mood = if (sleeping) Mood.SLEEPY else c.mood

    // тень
    val sh = 1f - j * 0.3f
    drawOval(
        Color(0x26000000),
        Offset(s * 0.5f - s * 0.26f * sh, s * 0.9f),
        Size(s * 0.52f * sh, s * 0.06f)
    )

    withTransform({
        translate(0f, -j * s * 0.14f)
        rotate(w * 6f, Offset(s * 0.5f, s * 0.9f))
    }) {
        // лапы
        drawOval(Orange, Offset(s * 0.30f, s * 0.86f), Size(s * 0.16f, s * 0.06f))
        if (sc < 0.02f) {
            drawOval(Orange, Offset(s * 0.54f, s * 0.86f), Size(s * 0.16f, s * 0.06f))
        } else {
            val start = Offset(s * 0.60f, s * 0.80f)
            val end = Offset(s * 0.62f + s * 0.10f * sc, s * 0.88f - s * 0.32f * sc)
            drawLine(Orange, start, end, strokeWidth = s * 0.035f, cap = StrokeCap.Round)
            drawCircle(Orange, s * 0.03f, end)
        }

        // крылья
        rotate(-w * 18f, Offset(s * 0.22f, s * 0.55f)) {
            drawOval(YellowDark, Offset(s * 0.14f, s * 0.52f), Size(s * 0.14f, s * 0.28f))
        }
        rotate(w * 18f, Offset(s * 0.78f, s * 0.55f)) {
            drawOval(YellowDark, Offset(s * 0.72f, s * 0.52f), Size(s * 0.14f, s * 0.28f))
        }

        // тело и голова
        drawOval(Yellow, Offset(s * 0.2f, s * 0.46f), Size(s * 0.6f, s * 0.44f))
        drawOval(YellowLight, Offset(s * 0.32f, s * 0.58f), Size(s * 0.36f, s * 0.28f))
        drawCircle(Yellow, s * 0.2f, Offset(s * 0.5f, s * 0.34f))
        drawOval(Yellow, Offset(s * 0.47f, s * 0.10f), Size(s * 0.05f, s * 0.09f))
        drawOval(Yellow, Offset(s * 0.52f, s * 0.11f), Size(s * 0.05f, s * 0.08f))

        // лицо
        val fx = look * s * 0.025f
        val ey = s * 0.32f
        val exL = s * 0.42f + fx
        val exR = s * 0.58f + fx
        val r = s * 0.035f
        when {
            eyeOpen < 0.2f && mood != Mood.HAPPY -> {
                closedEye(exL, ey, r)
                closedEye(exR, ey, r)
            }
            mood == Mood.HAPPY -> {
                happyEye(exL, ey, r)
                happyEye(exR, ey, r)
                drawCircle(Color(0x55FF5252), s * 0.035f, Offset(exL - s * 0.035f, ey + s * 0.07f))
                drawCircle(Color(0x55FF5252), s * 0.035f, Offset(exR + s * 0.035f, ey + s * 0.07f))
            }
            mood == Mood.SURPRISED -> {
                for (x in listOf(exL, exR)) {
                    drawCircle(Color.White, r * 1.5f, Offset(x, ey))
                    drawCircle(Ink, r * 1.5f, Offset(x, ey), style = Stroke(width = r * 0.25f))
                    drawCircle(Ink, r * 0.8f, Offset(x + fx * 0.3f, ey))
                }
            }
            mood == Mood.SLEEPY -> {
                normalEye(exL, ey, r, eyeOpen)
                normalEye(exR, ey, r, eyeOpen)
                drawRect(Yellow, Offset(exL - r * 1.3f, ey - r * 1.3f), Size(r * 2.6f, r * 1.5f))
                drawRect(Yellow, Offset(exR - r * 1.3f, ey - r * 1.3f), Size(r * 2.6f, r * 1.5f))
            }
            mood == Mood.SAD -> {
                normalEye(exL, ey, r, eyeOpen)
                normalEye(exR, ey, r, eyeOpen)
                val bw = r * 0.45f
                drawLine(Ink, Offset(exL - r * 1.3f, ey - r * 1.3f), Offset(exL + r * 1.3f, ey - r * 2.4f), bw, StrokeCap.Round)
                drawLine(Ink, Offset(exR - r * 1.3f, ey - r * 2.4f), Offset(exR + r * 1.3f, ey - r * 1.3f), bw, StrokeCap.Round)
                drawOval(Color(0xFF4FC3F7), Offset(exR + r * 0.6f, ey + r * 1.6f), Size(r * 0.9f, r * 1.4f))
            }
            else -> {
                normalEye(exL, ey, r, eyeOpen)
                normalEye(exR, ey, r, eyeOpen)
            }
        }

        // клюв
        val bx = s * 0.5f + fx * 1.2f
        val by = s * 0.40f
        if (mood == Mood.SURPRISED) {
            drawOval(Orange, Offset(bx - s * 0.04f, by - s * 0.01f), Size(s * 0.08f, s * 0.09f))
        } else {
            drawOval(Orange, Offset(bx - s * 0.08f, by), Size(s * 0.16f, s * 0.07f))
        }
    }
}
