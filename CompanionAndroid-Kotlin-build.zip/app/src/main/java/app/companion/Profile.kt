package app.companion

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder

private val EMOJIS = listOf(
    "🦆", "⭐", "🔥", "💜", "😎", "🚀", "🌈", "🎵", "🍀", "👑", "🐱", "🐸",
    "🌙", "⚡", "🎮", "🍕", "💎", "🦄", "🎧", "🌸", "😈", "🤖", "👻", "❤️"
)

@Composable
fun AnimatedEmoji(
    emoji: String,
    effect: EmojiEffect,
    speed: Float,
    enabled: Boolean,
    fontSize: TextUnit = 28.sp
) {
    if (emoji.isEmpty()) return
    if (!enabled) {
        Text(emoji, fontSize = fontSize)
        return
    }
    val t = rememberInfiniteTransition(label = "emoji")
    val period = (2400 / speed.coerceIn(0.25f, 3f)).toInt().coerceAtLeast(300)
    val spin = effect == EmojiEffect.SPIN
    val p by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(
            animation = tween(period, easing = if (spin) LinearEasing else FastOutSlowInEasing),
            repeatMode = if (spin) RepeatMode.Restart else RepeatMode.Reverse
        ),
        label = "emojiP"
    )
    Text(
        emoji,
        fontSize = fontSize,
        modifier = Modifier.graphicsLayer {
            when (effect) {
                EmojiEffect.SPIN -> rotationZ = p * 360f
                EmojiEffect.BOUNCE -> translationY = -p * 16.dp.toPx()
                EmojiEffect.PULSE -> {
                    val k = 0.85f + p * 0.4f
                    scaleX = k
                    scaleY = k
                }
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(vm: CompanionViewModel) {
    val ctx = LocalContext.current
    val loader = remember {
        ImageLoader.Builder(ctx).components {
            if (Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory()) else add(GifDecoder.Factory())
        }.build()
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && !vm.saveGif(uri)) {
            Toast.makeText(ctx, "Нужен файл GIF размером до 8 МБ", Toast.LENGTH_LONG).show()
        }
    }

    Box(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            Modifier.widthIn(max = 560.dp).fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // аватар
            Box(
                Modifier.size(120.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                val gif = vm.gifFile
                if (gif != null) {
                    AsyncImage(
                        model = gif,
                        contentDescription = "GIF-аватар",
                        imageLoader = loader,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text("🦆", fontSize = 56.sp)
                }
            }
            // имя + анимированный эмодзи
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Text(
                    vm.displayName.ifBlank { "Без имени" },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(8.dp))
                AnimatedEmoji(vm.emoji, vm.emojiEffect, vm.emojiSpeed, vm.emojiAnim)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch("image/gif") }) { Text("Выбрать GIF") }
                if (vm.gifFile != null) {
                    OutlinedButton(onClick = { vm.removeGif() }) { Text("Убрать GIF") }
                }
            }
            Text(
                "GIF хранится только на устройстве и анимируется внутри Companion. Это не аватар Telegram.",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center
            )

            Section("Имя") {
                OutlinedTextField(
                    value = vm.displayName,
                    onValueChange = vm::updateName,
                    singleLine = true,
                    label = { Text("Отображаемое имя") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Section("Эмодзи рядом с именем") {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    EMOJIS.forEach { e ->
                        Box(
                            Modifier.size(44.dp).clip(CircleShape)
                                .background(
                                    if (vm.emoji == e) MaterialTheme.colorScheme.primaryContainer
                                    else Color.Transparent
                                )
                                .clickable { vm.updateEmoji(e) },
                            contentAlignment = Alignment.Center
                        ) { Text(e, fontSize = 24.sp) }
                    }
                }
                TextButton(onClick = { vm.updateEmoji("") }) { Text("Без эмодзи") }
            }

            Section("Анимация эмодзи") {
                SettingSwitch("Включить анимацию", vm.emojiAnim, vm::updateEmojiAnim)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EmojiEffect.values().forEach { ef ->
                        FilterChip(
                            selected = vm.emojiEffect == ef,
                            onClick = { vm.updateEmojiEffect(ef) },
                            label = { Text(ef.label) }
                        )
                    }
                }
                Text("Скорость: x${"%.1f".format(vm.emojiSpeed)}")
                Slider(
                    value = vm.emojiSpeed,
                    onValueChange = vm::updateEmojiSpeed,
                    valueRange = 0.25f..3f
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: CompanionViewModel) {
    Box(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            Modifier.widthIn(max = 560.dp).fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Настройки", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

            Section("Companion") {
                SettingSwitch("Анимации утки", vm.animationsEnabled, vm::updateAnimations)
                Text(
                    "Выключено: утка стоит и реагирует только на касания. Это экономит батарею.",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Section("Озвучка ответов") {
                SettingSwitch("Озвучивать ответы", vm.ttsEnabled, vm::updateTts)
                if (!vm.ttsAvailable) {
                    Text(
                        "Служба озвучки на устройстве недоступна или ещё запускается.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text("Скорость: ${"%.1f".format(vm.ttsRate)}")
                Slider(value = vm.ttsRate, onValueChange = vm::updateRate, valueRange = 0.5f..2f)
                Text("Высота голоса: ${"%.1f".format(vm.ttsPitch)}")
                Slider(value = vm.ttsPitch, onValueChange = vm::updatePitch, valueRange = 0.5f..2f)
                OutlinedButton(onClick = { vm.speak("Кря! Я Companion.") }) { Text("Проверить голос") }
            }

            Section("Память") {
                SettingSwitch("Запоминать по просьбе", vm.memoryEnabled, vm::updateMemory)
                Text(
                    "Напиши в чате «запомни …» или «меня зовут …». Хранится только на этом устройстве.",
                    style = MaterialTheme.typography.bodySmall
                )
                if (vm.memories.isEmpty()) {
                    Text("Ничего не сохранено", style = MaterialTheme.typography.bodyMedium)
                } else {
                    vm.memories.forEachIndexed { i, m ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(m, Modifier.weight(1f))
                            IconButton(onClick = { vm.removeMemory(i) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Удалить")
                            }
                        }
                    }
                    OutlinedButton(onClick = { vm.clearMemories() }) { Text("Очистить всё") }
                }
            }

            Section("ИИ-сервер (необязательно)") {
                SettingSwitch("Использовать свой сервер", vm.backendEnabled, vm::updateBackendEnabled)
                OutlinedTextField(
                    value = vm.backendUrl,
                    onValueChange = vm::updateBackendUrl,
                    singleLine = true,
                    label = { Text("Адрес https://…") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Выключено по умолчанию: тогда работает демо-режим без интернета. " +
                        "Если включить, каждое отправленное сообщение (и память, если она включена) " +
                        "уходит на указанный адрес. Принимаются только https-адреса.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
